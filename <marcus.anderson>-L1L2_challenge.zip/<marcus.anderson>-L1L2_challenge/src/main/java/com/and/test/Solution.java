import java.util.ArrayList;

public class Solution {

    /**
     * The following is the method where the solution shall be written
     */

    public static ArrayList<String> solution(String input) throws NumberFormatException
    {
        String answer = "";
        int value = Integer.parseInt(input.replaceAll("[^0-9]", ""));
        answer = Integer.toString(value);

        ArrayList<String>  output = Permutate(answer);


        return output;
    }



    public static ArrayList<String> Permutate(String s)
    {
        ArrayList<String> arrayList = new ArrayList<String>();
        if (s==null)
        {
            return null;
        }
        else if (s.length() == 0)
        {
            arrayList.add("");
            return arrayList;
        }

        else
        {
            for (int i = 0; i < s.length(); i++)
            {
                ArrayList<String> remaining = Permutate(s.substring(0, i) + s.substring(i + 1));
                for (int j = 0; j < remaining.size(); j++){
                    arrayList.add(s.charAt(i) + remaining.get(j));
                }
            }
            return arrayList;
        }
    }





    public static void main(String args[]) {

        System.out.println(solution("326"));


    }

}